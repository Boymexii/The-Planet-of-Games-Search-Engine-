<?php
session_start();

if(isset($_SESSION['usr_id'])!="") {
    header("Location: index.php");
}

include_once 'dbconnect.php';

//check if form is submitted
if (isset($_POST['login'])) {

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $result = mysqli_query($con, "SELECT * FROM users WHERE email = '" . $email. "' and password = '" . md5($password) . "'");

    if ($row = mysqli_fetch_array($result)) {
        $_SESSION['usr_id'] = $row['id'];
        $_SESSION['usr_name'] = $row['name'];
        header("Location: index.php");
    } else {
        $errormsg = "Incorrect Email or Password!!!";
    }
}
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Login | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>

    <style>

    .login {
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background-color: white;
        top: 0;
        position: absolute;
        height: 555px;
        width: 350px;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }
    
    h2 {
        font-family: "Lato", sans-serif;
        margin-top: 30px;
        font-size: 30px;
    }
    
    .form-control {
        width: 300px;
        margin-top: 30px;
    }    
        
    body {
        background-color: #e7e7e7;        
    }    
        
    </style>

<body>
    
<div class="container">
    
    <div class="loginpara">
        
    </div>
    
    <div class="login">
        
        <h2 align="center">LOGIN</h2>
        
        <div class="row" align="center">
            <form name="loginform" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <input class="form-control" required="required" name="email" type="text" placeholder="Your e-mail address">
            
            <input class="form-control" required="required" name="password" type="password" placeholder="Your password">
            
            <button class="btn btn-primary" style="margin-top: 30px;" align="center" name="login" type="submit">Login NOW</button><br/>
            <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
            </form>
        </div>
        
        <div class="row" align="center" style="margin-top: 20px;">
            <p>OR</p>
            <a href="basicforgotpass.php"><button class="btn btn-primary" style="margin-top: 9px;" align="center" type="button">Forgot Password</button></a>
        </div>
        
        <div class="row" align="center" style="margin-top: 90px;">
            <p>New Here? <b><a href="basicsignup.php" style="color: black;">Create a new account</a></b></p>
        </div>
        
        
    </div>

</div>
     
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
</body>
    
</html>