<?php
session_start();
include_once '../dbconnect.php';
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Purchases | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="../images/logo/logo.png">
        <link rel="stylesheet" type="text/css" href="../css/results.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
        <style>
        
            body {
                background-color: #e7e7e7;
            }
            
            .below {
                height: 70px;
                top: 50px;
                width: 100%;
                right: 0px;
                left: 0px;
                position:absolute;
                background-color: white;
                border: 1px solid rgba(0,0,0,0.1);
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }
            
             .center {
                height: 390px;
                top: 140px;
                width: 900;
                right: 20px;
                left: 20px;
                position:absolute;
                background-color: white;
                border: 1px solid rgba(0,0,0,0.1);
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }
            
        </style>
        
        </head>
    
    <body>
        
               <!--- Header ---->
        <div class="resultsheader">
            <div class="container-fluid topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="../index.php" style="color: #e2e2e2;">THE PLANET</a>
                        </li>
                        <li>
                            <form action="../results.php" method="get">
                            <div class="input-group" style="width: 460px; margin-top: 8px;">
                                <input type="text" class="form-control" placeholder="e.g need for speed" name="user_keyword">
                            <span class="input-group-btn">
                                <button class="btn btn-success" type="submit" name="submit">Search!</button>
                            </span>
                            </div>
                            </form>
                        </li>
                    </ul>
                    
                    <ul class="nav navbar-nav navbar-right" style="margin-right: 3px; font-weight: 300;">
                        <?php if (isset($_SESSION['usr_id'])) { ?>
                            <li style="margin-right: -20px;"><a href="likes.php" style="color: #e2e2e2;"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -20px;"><a href="downloads.php" style="color: #e2e2e2;"><i class="fa fa-cloud-download" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -10px;"><a href="purchases.php" style="color: #e2e2e2;"><i class="fa fa-cart-plus" aria-hidden="true"></i></a></li>
                            <li>
                                <p class="navbar-text" style="color: #e2e2e2;">Welcome <?php echo $_SESSION['usr_name']; ?>!</p>
                            </li>
                            <li class="dropdown">
                                <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                <li><a href="dashboard.php" style="font-weight: 300;">Dashboard <i class="fa fa-tachometer" aria-hidden="true"></i></a></li>
                                <li><a href="#" style="font-weight: 300;">Edit Profile <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>
                                <li><a href="balance.php" style="font-weight: 300;">Account Balance <i class="fa fa-money" aria-hidden="true"></i></a></li>
                                <li><a href="../TPOGPRO/pro.php" style="font-weight: 300;">Upgrade to <b style="color: #95b98d;">PRO</b> <i class="fa fa-hand-o-up" aria-hidden="true"></i></a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#" style="font-weight: 300;">Help & Support <i class="fa fa-question-circle" aria-hidden="true"></i></a></li>    
                                <li><a href="../logout.php" style="font-weight: 300;">LOGOUT <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>  
                                </ul>
                            </li>
                            <?php } else { ?>
                            <li><a href="../login.php" style="color: #e2e2e2;">LOGIN <i class="fa fa-sign-in" aria-hidden="true"></i></a></li>
                            <li><a href="../signup.php" style="color: #e2e2e2;">SIGNUP <i class="fa fa-user-plus" aria-hidden="true"></i></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--- Below ---->
        <div class="below">
            
            <h3 style="margin-left: 30px;"><b>Your Purchases</b></h3>
            
        </div>
        
        
        <div class="center" align="center">
        
            <p style="margin-top: 135px; font-size: 30px;"><b>You haven't bought anything yet</b></p>
            <p style="font-size: 17px;">To purchase games, just click on the Buy button next to the game you want to buy.</p>
            
        </div>
        
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            
    </body>
    
</html>
        