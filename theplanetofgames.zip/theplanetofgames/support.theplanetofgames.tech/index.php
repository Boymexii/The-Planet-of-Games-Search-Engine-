<!DOCTYPE html>
<html lang="en">
<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>The Planet of Games | Knowledgebase</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="img/logo.png">
        <link rel="stylesheet" type="text/css" href="css/style.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>
    
    <body>
    
        
        <div class="header">
            <a href="../index.php" style="color: white;"><h2 class="headerhead"><img src="img/logo.png" alt="" style="height: 35px; width: 35px;"><b>THE PLANET OF GAMES</b></h2></a>
            <p style="font-weight: 300; font-size: 28px;" class="headerpara">Advice and answers from the TPOG Team</p>
        
            <div class="container">
            <div class="row">
                <input type="text" class="form-control" placeholder="Search for answers...">
            </div>
            </div>
                
        </div>
        
        <section style="margin-top: 35px;">
            <div class="supportbox"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
            <div class="supportbox" style="margin-top: 18px;"></div>
        </section>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-82643030-2', 'auto');
        ga('send', 'pageview');

        </script>
        
    </body>
    
</html>