<?php
session_start();
include_once 'dbconnect.php';
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Game Categories | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">
        <link rel="stylesheet" type="text/css" href="css/results.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
        <style>
        
            h3 {
                margin-top: -1px;
                margin-bottom: 10px;
                font-size: 45px;
                color: #d9d1d1;
                text-shadow: 0 1px 2px rgba(0,0,0,0.1);
                transition: all .2s ease-in-out;
            }
        
            h3:hover{
                transform: scale(1.1);
            }
            
            .starterpack {
                transition: all .2s ease-in-out;
            }
            
            .starterpack:hover {
                transform: scale(1.1);
            }
            
            center {
            
            }
            
        </style>
        
        
    </head>
    
    <body>
     
          <!--- Header ---->
        <div class="resultsheader">
            <div class="container-fluid topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="index.php" style="color: #e2e2e2;">THE PLANET</a>
                        </li>
                        <li>
                            <form action="results.php" method="get">
                            <div class="input-group" style="width: 460px; margin-top: 8px;">
                                <input type="text" class="form-control" placeholder="e.g need for speed" name="user_keyword">
                            <span class="input-group-btn">
                                <button class="btn btn-success" type="submit" name="submit">Search!</button>
                            </span>
                            </div>
                            </form>
                        </li>
                    </ul>
                    
                    <ul class="nav navbar-nav navbar-right" style="margin-right: 3px; font-weight: 300;">
                        <?php if (isset($_SESSION['usr_id'])) { ?>
                            <li style="margin-right: -20px;"><a href="account/likes.php" style="color: #e2e2e2;"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -20px;"><a href="account/downloads.php" style="color: #e2e2e2;"><i class="fa fa-cloud-download" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -10px;"><a href="account/purchases.php" style="color: #e2e2e2;"><i class="fa fa-cart-plus" aria-hidden="true"></i></a></li>
                            <li>
                                <p class="navbar-text" style="color: #e2e2e2;">Welcome <?php echo $_SESSION['usr_name']; ?>!</p>
                            </li>
                            <li class="dropdown">
                                <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                <li><a href="account/dashboard.php" style="font-weight: 300;">Dashboard <i class="fa fa-tachometer" aria-hidden="true"></i></a></li>
                                <li><a href="#" style="font-weight: 300;">Edit Profile <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>
                                <li><a href="account/balance.php" style="font-weight: 300;">Account Balance <i class="fa fa-money" aria-hidden="true"></i></a></li>
                                <li><a href="TPOGPRO/pro.php" style="font-weight: 300;">Upgrade to <b style="color: #95b98d;">PRO</b> <i class="fa fa-hand-o-up" aria-hidden="true"></i></a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#" style="font-weight: 300;">Help & Support <i class="fa fa-question-circle" aria-hidden="true"></i></a></li>    
                                <li><a href="logout.php" style="font-weight: 300;">LOGOUT <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>  
                                </ul>
                            </li>
                            <?php } else { ?>
                            <li><a href="login.php" style="color: #e2e2e2;">LOGIN <i class="fa fa-sign-in" aria-hidden="true"></i></a></li>
                            <li><a href="signup.php" style="color: #e2e2e2;">SIGNUP <i class="fa fa-user-plus" aria-hidden="true"></i></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    
        <!--- Button Navbar --->
            <nav class="navbar navbar-default" role="navigation" style="font-weight: 300;">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <ul class="nav navbar-nav navbar-left">
                        <li class="active">
                            <a href="#">ALL</a>
                        </li>
                        <li>
                            <a href="#">IMAGES</a>
                        </li>
                        <li>
                            <a href="#">VIDEOS</a>
                        </li>
                        <li>
                            <a href="reviews/reviews.php">REVIEWS</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PLATFORMS <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">PC</a></li>                          
                                <li><a href="#" style="font-weight: 300;">PS4</a></li>                             
                                <li><a href="#" style="font-weight: 300;">IOS</a></li>                              
                                <li><a href="#" style="font-weight: 300;">WII U</a></li>                           
                                <li><a href="#" style="font-weight: 300;">PS VITA</a></li>
                                <li><a href="#" style="font-weight: 300;">ANDROID</a></li>                         
                                <li><a href="#" style="font-weight: 300;">XBOX ONE</a></li>              
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">LANGUAGE <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">EN</a></li>                          
                                <li><a href="#" style="font-weight: 300;">RU</a></li>                             
                                <li><a href="#" style="font-weight: 300;">SP</a></li>                              
                                <li><a href="#" style="font-weight: 300;">AR</a></li>                           
                                <li><a href="#" style="font-weight: 300;">AD</a></li>
                                <li><a href="#" style="font-weight: 300;">EU</a></li>                         
                                <li><a href="#" style="font-weight: 300;">NG</a></li>              
                            </ul>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>
      
        
        
        <!---- Gaming Categories ---->
        <div class="container">
        
            <h3 align="center">TPOG Categories</h3>
            
            <!--- Category Divs --->
                 <a href="#"><div class="starterpack">
                     <center style="font-size: 30px; font-weight: 300;">Action</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack">
                     <center style="font-size: 30px; font-weight: 300;">Adventure</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack">
                     <center style="font-size: 30px; font-weight: 300;">Arcade</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack">
                     <center style="font-size: 30px; font-weight: 300;">Fighting</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack">
                     <center style="font-size: 30px; font-weight: 300;">Horror</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Puzzle</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Racing</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Shooting</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Simulation</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Sports</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">War</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Strategy</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Mystery</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Fantasy</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Sci-Fi</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">RPG</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
                 <a href="#"><div class="starterpack" style="margin-top: 20px;">
                     <center style="font-size: 30px; font-weight: 300;">Survival</center>
                     <center><img src="images/logo/free.png" style="margin-top: 19px;"></center>
                     </div>
                 </a>
    
            <div class="row"></div>
            
        </div>
    
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
         
        
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
    </body>

    
</html>