<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Admin Insert Games | The Planet of Games</title>
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="../images/logo/logo.png">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
        <style>
            
            body {
                font-family: 'Lato', sans-serif;
            }
        
        </style>
	</head>
	
<body bgcolor="#ffffff">
	
	<form action="insert_game.php" method="post" enctype="multipart/form-data"> 
		
		<table class="table table-bordered table-responsive" bgcolor="orange" style="margin: 0 auto; width: 500px; margin-top: 70px;" align="center">
			
			<tr>
				<td colspan="5" align="center"><h2>Inserting new game:</h2></td>
			</tr>
			<tr>
				<td align="right"><b>Game Title:</b></td>
				<td><input class="form-control" type="text" name="game_title" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Game Link:</b></td>
				<td><input class="form-control" type="text" name="game_link" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Game Keywords:</b></td>
				<td><input class="form-control" type="text" name="game_keywords" /></td>
			</tr>
			
			<tr>
				<td align="right"><b>Game Description:</b></td>
				<td><textarea class="form-control" cols="18" rows="8" name="game_desc"></textarea></td>
			</tr>
			
			<tr>
				<td align="right"><b>Game Image:</b></td>
				<td><input type="file" name="game_image" /></td>
			</tr>
			
			<tr>
				<td align="center" colspan="5"><input class="btn btn-default" type="submit" name="submit" value="Add Game Now"/></td>
			</tr>

		
		
		</table>
	
	
	</form>

    
   
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
</body>
    
</html>
<?php 
	$con = mysqli_connect("localhost","root","","theplanetofgames") or die("Error in connecting");
	
	if(isset($_POST['submit'])){
	
		 $game_title = $_POST['game_title'];
		 $game_link = $_POST['game_link'];
		 $game_keywords = $_POST['game_keywords'];
		 $game_desc = $_POST['game_desc'];
		 $game_image = $_FILES['game_image']['name'];
		 $game_image_tmp = $_FILES['game_image']['tmp_name'];
	
		
		if($game_title=='' OR $game_link=='' OR $game_keywords=='' OR $game_desc==''){
		
		echo "<script>alert('please fill all the fields!')</script>";
		
		exit();
		}
		else {
		
		$insert_query = "insert into games (game_title,game_link,game_keywords,game_desc,game_image) values ('$game_title','$game_link','$game_keywords','$game_desc','$game_image')";
		
		move_uploaded_file($game_image_tmp,"images/{$game_image}");
	
		if(mysqli_query($con,$insert_query)){
		
		echo "<script>alert('Data inserted into table')</script>";
		
		
		}
		
		}
	
	}


?>



