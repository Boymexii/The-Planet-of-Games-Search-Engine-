<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Log into your account | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">
        <link rel="stylesheet" type="text/css" href="css/index.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>
    
    <body>
        
        <!--- Header ---->
        <div class="headersignup">
            <div class="container-fluid topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="index.php" style="color: #e2e2e2;">THE PLANET</a>
                        </li>
                        <li>
                            <a href="reviews/reviews.php" style="color: #e2e2e2;">REVIEWS</a>
                        </li>
                        <li>
                            <a href="categories.php" style="color: #e2e2e2;">CATEGORIES</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PLATFORMS <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">PC</a></li>                          
                                <li><a href="#" style="font-weight: 300;">PS4</a></li>                             
                                <li><a href="#" style="font-weight: 300;">IOS</a></li>                              
                                <li><a href="#" style="font-weight: 300;">WII U</a></li>                           
                                <li><a href="#" style="font-weight: 300;">PS VITA</a></li>
                                <li><a href="#" style="font-weight: 300;">ANDROID</a></li>                         
                                <li><a href="#" style="font-weight: 300;">XBOX ONE</a></li>              
                            </ul>
                            </li>
                        <li class="dropdown">
                            <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">MORE <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">ABOUT US</a></li>
                                <li><a href="#" style="font-weight: 300;">CONTACT US</a></li>
                                <li><a href="#" style="font-weight: 300;">OUR SERVICES</a></li>
                                <li><a href="#" style="font-weight: 300;">TERMS AND CONDITIONS</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right" style="margin-right: 3px;">
                        <li>
                            <a href="login.php" style="color: #e2e2e2;">LOGIN <i class="fa fa-sign-in" aria-hidden="true"></i></a>
                        </li>
                        <li>
                            <a href="signup.php" style="color: #e2e2e2;">SIGNUP <i class="fa fa-user-plus" aria-hidden="true"></i></a>
                        </li>
                    </ul>
                </div>

                <!--- Sign Up Heading ---->
                <h1 align="center" style="font-size: 60px; color: #e2e2e2; margin-top: 35px;">
                    Log IN <img src="images/logo/login.png" style="height: 51px; width: 51px;">
                </h1>
                <p style="color: #e2e2e2; font-size: 20px;" align="center">
                    Now enter to see what we have in stock for you
                </p>
                <p style="color: #e2e2e2; font-size: 20px;" align="center">
                <i class="fa fa-sign-in" aria-hidden="true" style="font-size: 20px; color: #e2e2e2;"></i>
                </p>
            </div>        
        </div>
            
            <!--- login ---->
            <section class="signupsection">
                
                <div class="basictype">
                    <h4 class="starterpackheading" align="center" style="margin-top: 40px;">Basic <i class="fa fa-play-circle" aria-hidden="true"></i></h4>
                    
                    <div class="freebutton" align="center">
                    <a href="basiclogin.php"><button class="btn btn-success" style="background-color: #239d60;">Login Basic</button></a>
                    </div>
                    <p align="center" style="margin-top: 10px;">OR</p>
                    <div class="freebutton" align="center">
                    <a href="basicforgotpass.php"><button class="btn btn-success" style="background-color: #239d60;">Forgot Password</button></a>
                    </div>
                </div>
                
                <div class="startertype" align="center">
                    <h4 class="starterpackheading" align="center" style="margin-top: 40px;">Starter <i class="fa fa-play-circle" aria-hidden="true"></i></h4>
                    <a href="#"><button class="btn btn-success" style="background-color: #239d60;">Login Starter</button></a>
                    <p align="center" style="margin-top: 10px;">OR</p>
                    <a href="#"><button class="btn btn-success" style="background-color: #239d60;">Forgot Password</button></a>
                </div>
                
                <div class="unlimitedtype" align="center">
                    <h4 class="starterpackheading" align="center" style="margin-top: 40px;">Unlimited <i class="fa fa-play-circle" aria-hidden="true"></i></h4>
                    <a href="#"><button class="btn btn-success" style="background-color: #239d60;">Login Unlimited</button></a>
                    <p align="center" style="margin-top: 10px;">OR</p>
                    <a href="#"><button class="btn btn-success" style="background-color: #239d60;">Forgot Password</button></a>
                </div>
            
            </section>        
            
            
    
    <!--- Footer Menu --->
        <footer class="footer-menu-signup">
            <div class="col-md-4" style="margin-top: 35px; margin-left: 175px;" align="center">
                <p style="font-size: 25px;"> 
                  <img src="images/logo/logo.png" alt="logo" style="height: 33px; width: 33px;"> THE PLANET OF GAMES
                </p>
                <p style="margin-left: 23px; color: #999; font-size: 14px;">Made in Nigeria · Copyright 2016 · All rights reserved.</p>
                <p class="sociallinks" align="left">
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-snapchat" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;">Sign Up for our newsletter</a></p>
            </div>
            
            <div class="col-md-2" style="margin-top: 40px;">
                <p><a href="TPOGPRO/pro.php" style="color: #999;"><i class="fa fa-arrow-up" aria-hidden="true"></i> Upgrade now to <b style="color: #95b98d;">PRO</b></a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-code-fork" aria-hidden="true"></i> API</a></p>
                <p><a href="categories.php" style="color: #999;"><i class="fa fa-list" aria-hidden="true"></i> Categories</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-gamepad" aria-hidden="true"></i> Free Games</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-users" aria-hidden="true"></i> Become a contributor</a></p>
            </div>
            
            <div class="col-md-2" style="margin-top: 40px;">
                <p><a href="#" style="color: #999;"><i class="fa fa-question-circle-o" aria-hidden="true"></i> About The Planet of Games</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-briefcase" aria-hidden="true"></i> Jobs at TPOG</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-book" aria-hidden="true"></i> Terms and Conditions</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-user-secret" aria-hidden="true"></i> Privacy Policy</a></p>
            </div>
        </footer>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
           
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
    </body>
    
</html>