<?php
session_start();
include_once '../dbconnect.php';
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>The Planet of Games Pro | Download free pc games here . . .</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">
        <link rel="stylesheet" type="text/css" href="../css/index.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
        <style>
            
            .boxes {
                margin-top: 25px;
                margin-left: 32%;
            }
            
            
            .starterpack {
                margin-left: 20px;
                float: left;
                height: 265px;
                width: 200px;
                background-color: #fff;
                border: 1px solid rgba(0,0,0,0.1);
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }

            .starterpack:hover {
                transition: all .2s ease-in-out;
                -webkit-transform: scale(1.2);
                -ms-transform: scale(1.2);
                transform: scale(1.2);
            }

            .unlimitedpack {
                margin-left: 20px;
                float: left;
                height: 265px;
                width: 200px;
                background-color: #fff;
                border: 1px solid rgba(0,0,0,0.1);
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }
            
            .unlimitedpack:hover {
                 transition: all .2s ease-in-out;
                -webkit-transform: scale(1.2);
                -ms-transform: scale(1.2);
                 transform: scale(1.2);
            }
            
            .btn-success {
                border-top: none;
                border-bottom: none;
                border-left: none;
                border-right: none;
                border: 0px;
            }
            
            .frequent {
                margin-top: 20px;
                height: 580px;
                background-color: #eef3f2;
                border: 1px solid rgba(0,0,0,0.1);
                box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            }
            
        </style>
        
	</head>

    
    <body>
    
    
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="../index.php" style="color: black;">THE PLANET</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" style="color: #239d60; font-size: 18px;">FAQ</a>
                        </li>
                        <li>
                            <a href="#" style="color: #239d60; font-size: 18px;">Contact us</a>
                        </li>
                        <li>
                            <button class="btn btn-success" style="margin-top: 9px; background-color: #239d60;">Choose Plan</button>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>

        
        <div class="container-fluid" style="margin-top: 55px;">
            <center><h2 style="font-weight: 300; font-size: 40px; margin-top: 50px;">TPOG Pro</h2></center>
            <center><p class="lead" style="margin-left: 25%; margin-right: 25%; font-size: 24px; font-weight: 300; line-height: 1.4em; color: #333;">TPOG Pro subscription gives you an immediate access to the world's largest collection of games and gaming contents. The easiest way to get games with a license that fits personal and commercial purposes.</p></center>
            
            <!--- Boxes --->
            <!-- Starter Pack --->
            <div class="boxes">
                 <div class="starterpack">
                    
                    <h4 class="starterpackheading" align="center" style="color: #239d60;">Starter</h4>
                    <p class="startpackpara" align="center" style="font-weight: 300;">500 downloads/month</p>
                    <div class="row" align="center">
                    <span style="font-size: 27px; right: 10px; position: relative; bottom: 23px;">$</span> 
                    <span style="font-size: 67px;">3</span>
                    <p style="margin-top: -20px; font-weight: 200;">Per Month</p>
                    <p style="font-size: 19px; font-weight: 300; color: #999;">Single user only</p>
                    <a href="#"><button class="btn btn-success" style="width: 180px; background-color: #239d60; font-size: 18px;">Choose Starter</button></a>
                     </div>
                 </div>
                 
                 <!-- Unlimited Pack --->
                 <div class="unlimitedpack">
                    
                    <h4 class="unlimitedpackheading" align="center" style="color: #239d60;">Unlimited</h4>
                    <p class="unlimitedpackpara" align="center" style="font-weight: 300; font-size: 15px; color: #666;">Unlimited downloads</p>
                    <div class="row" align="center">
                    <span style="font-size: 27px; right: 10px; position: relative; bottom: 23px;">$</span> 
                    <span style="font-size: 67px;">5</span>
                    <p style="margin-top: -20px; font-weight: 200;">Per Month</p>
                    <p style="font-size: 19px; font-weight: 300; color: #999;">$5 / additional user</p>
                    <a href="#"><button class="btn btn-success" style="width: 180px; background-color: #239d60; font-size: 18px;">Choose Unlimited</button></a>
                     </div>
                 </div>
            </div>
        
            
        </div>
    
        <p style="font-weight: 400; color: #aaa; margin-top: 10px; font-size: 14px;" align="center">Pay by credit card or invoice</p>
        
        <p style="margin-top: 30px; color: #aaa; font-size: 20px;" align="center">Trusted by</p>
        
        <hr>
            
        <p align="center" style="color: #239d60; margin-top: 50px; font-size: 30px; line-height: normal;">500,355+ games at your mouse clicks</p>
        
        <p align="center" style="font-size: 24px; line-height: 1.5em; font-weight: 300; margin-left: 25%; margin-right: 25%; margin-bottom: 50px;">
            It's more than just a number. It's what ensures that you can find the perfect game for you to play and share.
        </p>
        
        <div class="frequent" style="margin-bottom: 35px;">
            <h2 align="center" style="margin-top: 40px;">Frequently Asked Questions</h2>
            <p align="center" style="color: #666; font-size: 1.5em; margin-right: 22%; margin-left: 22%;">If you have any further questions about TPOG Pro, you can check out the <a href="#">Help & Support</a> section or <a href="#">drop us a line.</a></p>
            
            <div class="col" style="margin-left: 17%; margin-top: 30px;">
            <div class="col-lg-5">
                <p style="color: #242424; font-size: 16px;">How is my subscription billed?</p>
                <p style="font-size: 14px; font-weight: 300;">Choosing monthly billing means your credit card gets charged once every month. If you choose annual billing, you pay for 12 months at once, but at the price of only 10 months.</p>
                
                <p style="color: #242424; font-size: 16px;">Can I cancel my plan at any time?</p>
                <p style="font-size: 14px; font-weight: 300;">Yes, there is a button in your account page with that sole purpose. When you press it you cancel future payments to your subscription, but are still a Pro member until your subscription runs out.</p>
                
                <p style="color: #242424; font-size: 16px;">Can I upgrade my Starter plan to Unlimited if I need it?</p>
                <p style="font-size: 14px; font-weight: 300;">Yes you can. At any point you can upgrade to Unlimited and just pay the difference. If you feel like you need to downgrade back to the Starter plan, you can do that too.</p>
            </div>
            
            <div class="col-lg-5">
                <p style="color: #242424; font-size: 16px;">Does Unlimited really mean unlimited?</p>
                <p style="font-size: 14px; font-weight: 300;">Well yes, as long as you don’t abuse the service. You can download all the games you want and different contents, but you can’t do abusive things like scrape and download a copy of all game contents on the site. Read the <a href="#">Terms of service</a> for more details.</p>
                
                <p style="color: #242424; font-size: 16px;">What happens to my games, if I cancel my subscription?</p>
                <p style="font-size: 14px; font-weight: 300;">The ones you have already downloaded, you can still play. But you no longer have access to download any premium games on The Planet of Games.</p>
                
                <p style="color: #242424; font-size: 16px;">Can I pay for TPOG Pro with PayPal?</p>
                <p style="font-size: 14px; font-weight: 300;">Yes you can.</p>
            </div>
            </div>
            
            <!---- TPOG Pro Sign up button
            <button class="btn btn-success" style="width: 200px; background-color: #239d60; font-size: 18px; margin-top: 45px;">Sign up for TPOG Pro</button>
            ---->
                
        </div>
        
        <div class="footer" style="margin-bottom: 40px;">
            <h3 align="center" style="color: #999;">THE PLANET</h3>
            <p align="center" style="font-size: 14px; color: #999;">Made in Nigeria · Copyright 2016 · All rights reserved</p>
        </div>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
    </body>

</html>