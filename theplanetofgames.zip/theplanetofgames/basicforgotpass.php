<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Forgot Password ? | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>

    <style>

    body {
        background-color: #e7e7e7;
    }    
        
    .login {
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background-color: white;
        top: 0;
        position: absolute;
        height: 555px;
        width: 350px;
        right: ;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }  
        
    h2 {
        font-family: "Lato", sans-serif;
        margin-top: 30px;
        font-size: 30px;
    }
    
    .form-control {
        width: 300px;
        margin-top: 30px;
    }    
        
    </style>

<body>
    
<div class="container">
    
    <div class="login">
        
        <h2 align="center">FORGOT PASS</h2>
        
        <div class="row" align="center">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
            <input class="form-control" required="required" name="name"  type="text" placeholder="Enter your e-mail address">   
                
            <input class="form-control" required="required" name="email" type="password" placeholder="Enter your new password">     
            
            <input class="form-control" required="required" name="password" type="password" placeholder="Confirm new password">
            
            <button class="btn btn-primary" style="margin-top: 30px;" align="center" name="signup" type="submit">RESET PASS</button><br/>
            </form>
        </div>
        
        <div class="row" align="center" style="margin-top: 50px;">
            <p>Already Registered? <b><a href="basiclogin.php" style="color: black;">Login Here</a></b></p>
        </div>
        
        
    </div>

</div>
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
</body>
    
</html>