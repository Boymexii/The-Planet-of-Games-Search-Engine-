<?php
session_start();
include_once 'dbconnect.php';
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>The Planet of Games | Download free pc games here . . .</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">
        <link rel="stylesheet" type="text/css" href="css/index.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>

    <body>
        
        <div class="header">
            <div class="container-fluid topnav">

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="index.php" style="color: #e2e2e2;">THE PLANET</a>
                        </li>
                        <li>
                            <a href="reviews/reviews.php" style="color: #e2e2e2;">REVIEWS</a>
                        </li>
                        <li>
                            <a href="categories.php" style="color: #e2e2e2;">CATEGORIES</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">PLATFORMS <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">PC</a></li>                          
                                <li><a href="#" style="font-weight: 300;">PS4</a></li>                             
                                <li><a href="#" style="font-weight: 300;">IOS</a></li>                              
                                <li><a href="#" style="font-weight: 300;">WII U</a></li>                           
                                <li><a href="#" style="font-weight: 300;">PS VITA</a></li>
                                <li><a href="#" style="font-weight: 300;">ANDROID</a></li>                         
                                <li><a href="#" style="font-weight: 300;">XBOX ONE</a></li>              
                            </ul>
                            </li>
                        <li class="dropdown">
                            <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">MORE <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#" style="font-weight: 300;">ABOUT US</a></li>
                                <li><a href="#" style="font-weight: 300;">CONTACT US</a></li>
                                <li><a href="#" style="font-weight: 300;">OUR SERVICES</a></li>
                                <li><a href="#" style="font-weight: 300;">TERMS AND CONDITIONS</a></li>
                            </ul>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right" style="margin-right: 3px;">
                        <?php if (isset($_SESSION['usr_id'])) { ?>
                            <li style="margin-right: -20px;"><a href="account/likes.php" style="color: #e2e2e2;"><i class="fa fa-heart" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -20px;"><a href="account/downloads.php" style="color: #e2e2e2;"><i class="fa fa-cloud-download" aria-hidden="true"></i></a></li>
                            <li style="margin-right: -10px;"><a href="account/purchases.php" style="color: #e2e2e2;"><i class="fa fa-cart-plus" aria-hidden="true"></i></a></li>
                            <li><p class="navbar-text">Welcome <?php echo $_SESSION['usr_name']; ?>!</p></li>
                            <li class="dropdown">
                                <a href="#" style="color: #e2e2e2;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                <li><a href="account/dashboard.php" style="font-weight: 300;">Dashboard <i class="fa fa-tachometer" aria-hidden="true"></i></a></li>
                                <li><a href="#" style="font-weight: 300;">Edit Profile <i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></li>
                                <li><a href="account/balance.php" style="font-weight: 300;">Account Balance <i class="fa fa-money" aria-hidden="true"></i></a></li>
                                <li><a href="TPOGPRO/pro.php" style="font-weight: 300;">Upgrade to <b style="color: #95b98d;">PRO</b> <i class="fa fa-hand-o-up" aria-hidden="true"></i></a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#" style="font-weight: 300;">Help & Support <i class="fa fa-question-circle" aria-hidden="true"></i></a></li>    
                                <li><a href="logout.php" style="font-weight: 300;">LOGOUT <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>  
                                </ul>
                            </li>
                            <?php } else { ?>
                            <li><a href="login.php" style="color: #e2e2e2;">LOGIN <i class="fa fa-sign-in" aria-hidden="true"></i></a></li>
                            <li><a href="signup.php" style="color: #e2e2e2;">SIGNUP <i class="fa fa-user-plus" aria-hidden="true"></i></a></li>
                        <?php } ?>
                    </ul>
                </div>

            </div>
        
        <div class="container-fluid">    
        <h1 align="center">
            <img src="images/logo/logo.png" alt="logo" style="height: 50px; width: 50px;"> THE PLANET OF GAMES
        </h1>
    
            <div class="row" align="center">
                <form action="results.php" method="get">
                <input class="form-control" type="text" name="user_query" placeholder="Search for free games here . . ." />
                <input class="btn btn-default" type="submit" name="search"  value="Seach NOW" />
                </form>
            </div>
            
            <p class="p" align="center">Search through 500,355+ games or browse 50 game categories.</p>
            <p class="p" align="center"><i class="fa fa-money" aria-hidden="true"></i> Want to donate to <b>Us ?</b></p>
            
            </div>
                
        </div>
        
        <div class="container">
            <!--- Section ---->
             <section class="section">
        
                <div class="signupdiv">
                    <h3 align="center">Sign Up for TPOG PRO</h3>
                    <p class="section" style="font-weight: 300;" align="center">Dive into the largest collection of premium gaming content in the world for just $3/month</p>
                </div>
                 
                <!--- Gaming Pro --->
                <div class="gamingpro">
                    
                    <h4 class="h4" align="center">Why you'll <i class="fa fa-heart-o" aria-hidden="true"></i> TPOG PRO </h4>
                    <p style="margin-left: 35px;"><i class="fa fa-check" aria-hidden="true"></i> Access to all 500,355 games</p>
                    <p style="margin-left: 35px;"><i class="fa fa-check" aria-hidden="true"></i> Get the latest game updates</p>
                    <p style="margin-left: 35px;"><i class="fa fa-check" aria-hidden="true"></i> Get 70% discount to buy new releases</p>
                    <p style="margin-left: 35px;"><i class="fa fa-check" aria-hidden="true"></i> Add your entire game categories</p>
                    <p style="margin-left: 35px;"><i class="fa fa-check" aria-hidden="true"></i> Get free access to game reviews</p>
                    
                    <!----- Button ---->
                    <div class="button" align="center">
                        <a href="#"><button class="btn btn-primary" type="button" style="background-color: white; color: black;">Read More about <b>TPOG PRO</b></button></a>
                    </div>
                    
                 </div>
                 
                 <!-- Starter Pack --->
                 <div class="starterpack">
                    
                    <h4 class="starterpackheading" align="center">Starter <i class="fa fa-play-circle" aria-hidden="true"></i></h4>
                    <p class="startpackpara" align="center">500 downloads/month</p>
                    <div class="row" align="center">
                    <span style="font-size: 27px; right: 10px; position: relative; bottom: 23px;">$</span> 
                    <span style="font-size: 67px;">3</span>
                    <p>Per Month</p>
                    <a href="#"><button class="btn btn-success" style="width: 180px; background-color: #239d60; font-size: 18px; margin-top: -8px; border: none;">Choose Starter</button></a>
                     </div>
                 </div>
                 
                 <!-- Unlimited Pack --->
                 <div class="unlimitedpack">
                    
                    <h4 class="unlimitedpackheading" align="center">Unlimited <i class="fa fa-play-circle" aria-hidden="true"></i></h4>
                    <p class="unlimitedpackpara" align="center">Unlimited downloads</p>
                    <div class="row" align="center">
                    <span style="font-size: 27px; right: 10px; position: relative; bottom: 23px;">$</span> 
                    <span style="font-size: 67px;">5</span>
                    <p>Per Month</p>
                    <a href="#"><button class="btn btn-success" style="width: 180px; background-color: #239d60; font-size: 18px; margin-top: -8px; border: none;">Choose Unlimited</button></a>
                     </div>
                 </div>
                 
            </section>
            
            <div class="footerrow" style="margin-top: 15px;">
            <p align="center">
                <a href="#">Frequently asked question |</a>
                <a href="#"> Contact Us |</a>
                <a href="#"> About Us |</a>
                <a href="#"> Terms and Conditions</a>
            </p>
            </div>
        </div> 
        
        <hr>
    
        <!--- Featured free games ---->
        <div class="featuredgames">
            <div class="container">
                <p style="font-size: 20px;">Latest news from games you liked</p>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4"></div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>
        
        <!--- Featured free games ---->
        <div class="featuredgames">
            <div class="container">
                <p style="font-size: 20px;">Featured premium games</p>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4"></div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>
        
        <!---- Featured free games ---->
        <div class="featuredgames">
            <div class="container">
                <p style="font-size: 20px;">Featured free games</p>
                <div class="row">
                    <div class="col-md-4">
                        <img src="http://www.gameforsave.com/wp-content/uploads/2015/06/FAR-CRY-4.jpg" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 100px;">Far Cry 4</p>
                    </div>
                    <div class="col-md-4">
                        <img src="http://wallpapersdsc.net/wp-content/uploads/2015/10/Mafia_3_12.jpg" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 100px;">Mafia III</p>
                    </div>
                    <div class="col-md-4">
                        <img src="https://i.ytimg.com/vi/c7nRTF2SowQ/maxresdefault.jpg" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 90px;">Battlefield 1</p>
                    </div>
                    
                    <div class="col-md-4">
                        <img src="https://i.ytimg.com/vi/NFvT3hTlehM/maxresdefault.jpg" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 100px;">GTA V</p>
                    </div>
                    <div class="col-md-4">
                        <img src="https://images2.alphacoders.com/597/597965.jpg" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 60px;">COD: Black Ops 3</p>
                    </div>
                    <div class="col-md-4">
                        <img src="http://cdn.uploadvr.com/wp-content/uploads/2016/08/BankLimitABR_screenshot02.png" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 60px;">Bank Limit Racing</p>
                    </div>
                    
                    <div class="col-md-4">
                        <img src="https://media.playstation.com/is/image/SCEA/need-for-speed-rivals-listing-thumb-01-ps4-us-14jan15?$Icon$" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 50px;">Need for Speed: Rivals</p>
                    </div>
                    <div class="col-md-4">
                        <img src="https://cdn.arstechnica.net/wp-content/uploads/2016/08/nomanssky-header.png" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 80px;">No Man's Sky</p>
                    </div>
                    <div class="col-md-4">
                        <img src="http://images.akamai.steamusercontent.com/ugc/279595726555672334/11DAA257BD940BC0C3F62E12D3D2770B4395A420/" alt="" style="width: 270px; height: 200px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.1);">
                        <p style="font-weight: 300; font-size: 18px; margin-left: 90px;">Dark Souls 3</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!--- Game Categories ---->
        <div class="featuredgames">
           <div class="container">
            <p style="font-size: 20px;">Categories</p>
                <div class="row">
                    <!--- Firs columns --->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Action</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Adventure</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Arcade</button></div>
                    
                    <!--- Second columns --->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Fighting</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Horror</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Puzzle</button></div>
                    
                    <!--- Third Column ---->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Racing</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Shooting Games</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Simulation</button></div>
                    
                    <!--- Fourth Column ---->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Sports</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">War</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Strategy</button></div>
                    
                    <!--- Fifth Column ---->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Mystery</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Fantasy</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Sci-Fi</button></div>
                    
                    <!--- Sixth Column ---->
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">RPG</button></div>
                    <div class="col-md-2" style="margin-top: 10px;"><button class="btn btn-success" style="background-color: #239d60;">Survival</button></div>
                </div>
            </div>
        </div>
        
        <!--- Footer Menu --->
        <footer class="footer-menu">
            <div class="col-md-4" style="margin-top: 35px; margin-left: 175px;" align="center">
                <p style="font-size: 25px;"> 
                  <img src="images/logo/logo.png" alt="logo" style="height: 33px; width: 33px;"> THE PLANET OF GAMES
                </p>
                <p style="margin-left: 23px; color: #999; font-size: 14px;">Made in Nigeria · Copyright 2016 · All rights reserved.</p>
                <p class="sociallinks" align="left">
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;"><i class="fa fa-snapchat" aria-hidden="true"></i></a>
                <a href="#" style="color: #999; margin-right: 3px;">Sign Up for our newsletter</a></p>
                <p></p>
            </div>
            
            <div class="col-md-2" style="margin-top: 40px;">
                <p><a href="TPOGPRO/pro.php" style="color: #999;"><i class="fa fa-arrow-up" aria-hidden="true"></i> Upgrade now to <b style="color: #95b98d;">PRO</b></a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-code-fork" aria-hidden="true"></i> API</a></p>
                <p><a href="categories.php" style="color: #999;"><i class="fa fa-list" aria-hidden="true"></i> Categories</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-gamepad" aria-hidden="true"></i> Free Games</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-users" aria-hidden="true"></i> Become a contributor</a></p>
            </div>
            
            <div class="col-md-2" style="margin-top: 40px;">
                <p><a href="#" style="color: #999;"><i class="fa fa-question-circle-o" aria-hidden="true"></i> About The Planet of Games</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-briefcase" aria-hidden="true"></i> Jobs at TPOG</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-book" aria-hidden="true"></i> Terms and Conditions</a></p>
                <p><a href="#" style="color: #999;"><i class="fa fa-user-secret" aria-hidden="true"></i> Privacy Policy</a></p>
            </div>
        </footer>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
    </body>
    
</html>