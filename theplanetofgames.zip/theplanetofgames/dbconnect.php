<?php
//connect to mysql database
$con = mysqli_connect("localhost", "root", "emekass123", "theplanetofgames") or die("Error " . mysqli_error($con));
?>