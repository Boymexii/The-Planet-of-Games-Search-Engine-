<?php
session_start();

if(isset($_SESSION['usr_id'])) {
    header("Location: index.php");
}

include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['signup'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cpassword = mysqli_real_escape_string($con, $_POST['cpassword']);
    
    //name can contain only alpha characters and space
    if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
        $error = true;
        $name_error = "Name must contain only alphabets and space";
    }
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $email_error = "Please Enter Valid Email ID";
    }
    if(strlen($password) < 6) {
        $error = true;
        $password_error = "Password must be minimum of 6 characters";
    }
    if($password != $cpassword) {
        $error = true;
        $cpassword_error = "Password and Confirm Password doesn't match";
    }
    if (!$error) {
        if(mysqli_query($con, "INSERT INTO users(name,email,password) VALUES('" . $name . "', '" . $email . "', '" . md5($password) . "')")) {
            $successmsg = "Successfully Registered! <a href='basiclogin.php'>Click here to Login</a>";
        } else {
            $errormsg = "Error in registering...Please try again later!";
        }
    }
}
?>

<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Sign Up | The Planet of Games</title>
        <meta name="keywords" content="free games, game search, gamefinder, market place">
        <meta name="description" content="The Planet of Games has the largest collections of pc game setups for free downloads.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="The Planet of Games">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="icon" href="images/logo/logo.png">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>

    <style>

    .login {
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background-color: white;
        top: 0;
        position: absolute;
        height: 555px;
        width: 350px;
        right: ;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }  
        
    h2 {
        font-family: "Lato", sans-serif;
        margin-top: 40px;
        font-size: 30px;
    }
    
    .form-control {
        width: 300px;
        margin-top: 30px;
    }   
        
    body {
        background-color: #e7e7e7;        
    }    
    
    </style>

<body>
    
<div class="container">
    
    <div class="login">
        
        <h2 align="center">SIGNUP</h2>
        
        <div class="row" align="center">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
            <input class="form-control" required="required" name="name"  type="text" value="<?php if($error) echo $name; ?>" placeholder="Enter your username">
            <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>    
                
            <input class="form-control" required="required" name="email" type="text" value="<?php if($error) echo $email; ?>" placeholder="Enter your e-mail address">    
            <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>    
            
            <input class="form-control" required="required" name="password" type="password" placeholder="Enter your password">
            <span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
                
            <input class="form-control" required="required" name="cpassword" type="password" placeholder="Re-type your password">
            <span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
            
            <button class="btn btn-primary" style="margin-top: 30px;" align="center" name="signup" type="submit">Signup NOW</button><br/>
            </form>
            <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span><br/>
            <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
        </div>
        
        <div class="row" align="center" style="margin-top: 40px;">
            <p>Already Registered? <b><a href="basiclogin.php" style="color: black;">Login Here</a></b></p>
        </div>
        
        
    </div>

</div>
      
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-82643030-2', 'auto');
  ga('send', 'pageview');

</script>
</body>
    
</html>